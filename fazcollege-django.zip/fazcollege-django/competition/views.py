import json
from django.http import JsonResponse, HttpResponse
from django.views.decorators.csrf import ensure_csrf_cookie
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect
from django.contrib import messages
from .models import Student, Competition
import csv
from django.views.decorators.csrf import csrf_exempt

#  CSRF endpoint
@csrf_exempt
def register_view(request):
    if request.method == 'POST':
        try:
            import json
            data = json.loads(request.body)

            # Extract form data
            username = data.get('username')
            student_name = data.get('studentFullName')
            grade_level = data.get('gradeLevel')
            school_name = data.get('schoolName')
            dob = data.get('dob')
            address = data.get('address')
            religion = data.get('religion')
            has_written_cbt = data.get('hasWrittenCbt') == 'true'
            parent_name = data.get('parentFullName')
            parent_email = data.get('parentEmail')
            parent_phone = data.get('parentPhone')
            password = data.get('password')
            confirm_password = data.get('confirmPassword')
            competition_date = data.get('competitionDate')

            # Basic validation
            if not all ([student_name, parent_email, password]):
                print("missing:", {
                    "student name" : student_name,
                    "parent_email" : parent_email,
                    "password" : password
                })
                print(dob, type(dob));
                return JsonResponse({'error': 'Required fields are missing.'}, status=400)
            if password != confirm_password:
                return JsonResponse({'error': 'Passwords do not match.'}, status=400)

            # Handle competition
            

            # Save student (not User model)
            student = Student.objects.create(
                username = username,
                full_name = student_name,
                grade_level = grade_level,
                school_name=school_name,
                dob=dob,
                address=address,
                religion=religion,
                has_written_cbt=has_written_cbt,
                parent_name=parent_name,
                parent_email=parent_email,
                parent_phone=parent_phone,
                password=password,
                competition=competition_date,
            )

            return JsonResponse({'message': 'Registration successful!'}, status=201)
            request.session['username'] = student.username
            return redirect('api/dashboard')

        except json.JSONDecodeError:
            return JsonResponse({'error': 'Invalid JSON format.'}, status=400)

        except Exception as e:
            return JsonResponse({'error': str(e)}, status=500)

    return JsonResponse({'error': 'Only POST method is allowed.'}, status=405)


#  Login View (session-based)
def login_view(request):
    if request.method == 'POST':
        try:
            import json
            data = json.loads(request.body)

            username = data.get('username')
            password = data.get('password')

            user = authenticate(request, username=username, password=password)
            if user:
                login(request, user)
                return JsonResponse({'message': "Login successful"}, status=200)
                request.session['username'] = student.username
                return redirect('api/dashboard')
            return JsonResponse({'error': "Invalid credentials"}, status=400)
        except json.JSONDecodeError:
            return JsonResponse({'error': "Invalid JSON"}, status=400)

    return JsonResponse({'error': "Only POST method allowed"}, status=405)

#  Dashboard View (requires login)
@login_required
def dashboard_view(request):
    username = request.session.get('username')
    if not username:
        return redirect('/api/login')
    try:
        student = Student.objects.get(username = username)
        return redirect("api/dashboard")
    except:Student.DoesNotExist:
        return redirect('/api/login')   
    return JsonResponse({'message': f'Welcome, {student_username}!'}, status=200)

#  Logout
def logout_view(request):
    logout(request)
    return JsonResponse({'message': 'Logged out'}, status=200)

# Export CSV
def export_participants_csv(request):
    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename="participants.csv"'

    writer = csv.writer(response)
    writer.writerow(['Username', 'Grade', 'School', 'Parent Name', 'Phone', 'Date'])

    for profile in ParticipantProfile.objects.all():
        writer.writerow([
            profile.user.username,
            profile.grade,
            profile.school_name,
            profile.parent_name,
            profile.phone_number,
            profile.selected_competition_date
        ])
    return response
