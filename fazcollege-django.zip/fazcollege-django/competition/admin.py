from django.contrib import admin
from django.contrib.auth.models import User
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin
from .models import Student, Competition, Submission
from django.db import models
from django.contrib.auth.models import User

@admin.register(Student)
class StudentAdmin(admin.ModelAdmin):
    list_display = ("username", "full_name", "grade_level", "school_name", "competition")
    search_fields = ("full_name", "school_name", "parent_name")
    list_filter = ("competition", "grade_level")

@admin.register(Competition)
class CompetitionAdmin(admin.ModelAdmin):
    list_display = ("title", "date", "is_active")
    search_fields = ("title",)
    list_filter = ("is_active",)

@admin.register(Submission)
class SubmissionAdmin(admin.ModelAdmin):
    list_display = ("student", "submitted_at")
    search_fields = ("student__full_name",)
