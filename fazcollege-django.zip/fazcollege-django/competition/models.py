from django.db import models
from django.contrib.auth.models import User

# Top-level competition model
class Competition(models.Model):
    title = models.CharField(max_length=100)
    description = models.TextField()
    date = models.DateField()
    is_active = models.BooleanField(default=True)

    def __str__(self):
        return self.title

# Registered student model (no relation to User model)
class Student(models.Model):
    # Student Info
    username = models.CharField(max_length=50, unique=True)
    full_name = models.CharField(max_length=100)
    grade_level = models.CharField(max_length=50)
    school_name = models.CharField(max_length=100)
    dob = models.DateField()
    address = models.CharField(max_length=200)
    religion = models.CharField(max_length=50)
    has_written_cbt = models.BooleanField(default=False)
 
    password = models.CharField(max_length=128)  # hashed password later

    # Parent Info
    parent_name = models.CharField(max_length=100)
    parent_email = models.EmailField()
    parent_phone = models.CharField(max_length=20)

    # Relationship
    competition = models.CharField(max_length=20 , null = True)

    def __str__(self):
        return f"{self.full_name} - {self.competition}"

# Optional for storing student submissions
class Submission(models.Model):
    student = models.ForeignKey(Student, on_delete=models.CASCADE, null = True, blank = True)
    entry_file = models.FileField(upload_to='submissions/')
    submitted_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.student.full_name} - {self.student.competition.title}"

